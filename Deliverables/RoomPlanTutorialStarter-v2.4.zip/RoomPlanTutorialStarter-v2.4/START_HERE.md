# Start Here

이 ZIP은 `tutorial-starter-v2.4`의 빌드 가능한 Starter snapshot입니다.

- 열 파일: `RoomPlanExampleApp.xcodeproj`
- 첫 checkpoint: **Start Part 1**
- Main Tutorial: Sections 1~6, 약 60~80분
- 수정 파일: `App/OnboardingViewController.swift`, `ObjectExplorer/ObjectExplorerViewController.swift`
- 제공 asset: project-original CC0 `RoomPlanExampleApp/Resources/Furniture/Chair.usdz`
- 공개 DocC Overview: <https://woozy-a.github.io/2026TechMap_tutorial/tutorials/roomplanobjectexplorer/>

Overview에서 **RoomPlan Object Explorer 만들기**를 선택하고 Section 1부터 Section 6까지 순서대로 진행하세요. Starter의 빈 tutorial hook만 안내에 따라 수정하고, `Starter-provided` MARK 아래의 UIKit, RealityKit, camera, asset-fitting 코드는 그대로 둡니다.
