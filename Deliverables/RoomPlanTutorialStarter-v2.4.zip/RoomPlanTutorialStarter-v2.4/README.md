# RoomPlan Object Explorer — Tutorial Starter v2.4

이 프로젝트는 RoomPlan hands-on DocC Tutorial의 시작점입니다.

`Room.json`에서 `CapturedRoom`을 얻고, 객체 목록·선택·3D Highlight·Chair 교체·90° 회전을 Section 1부터 6까지 직접 구현합니다. UIKit 화면, non-AR RealityKit scene, room framing, table helper, 3D asset loading/fitting은 Starter가 제공합니다.

1. `RoomPlanExampleApp.xcodeproj`를 Xcode에서 엽니다.
2. iOS 17 이상 iPhone Simulator를 선택합니다.
3. `Command-R`로 실행하고 **Explore Sample Room**을 누릅니다.
4. **Start Part 1** 안내가 보이면 [공개 DocC Overview](https://woozy-a.github.io/2026TechMap_tutorial/tutorials/roomplanobjectexplorer/)에서 **RoomPlan Object Explorer 만들기**를 선택해 Section 1~6을 순서대로 진행합니다.

Main Tutorial은 LiDAR 없이 진행할 수 있습니다. **Scan Your Own Room** Challenge는 LiDAR가 있는 실제 iPhone 또는 iPad가 필요합니다.
