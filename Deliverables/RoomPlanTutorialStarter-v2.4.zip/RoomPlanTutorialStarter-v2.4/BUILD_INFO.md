# Build Identity

- Package: `RoomPlanTutorialStarter-v2.4.zip`
- Source ref: `tutorial-starter-v2.4`
- Annotated tag object: `d7de003e5647187be46e77337c0112dac9fff3dc`
- Peeled source commit: `80a4f6e97647919fbe83db34ff69106634350c2a`
- Source tree: `a690650aed24a7b44c26163e936d96668ea83d69`
- Expected baseline: **Start Part 1**
- Main Tutorial: **Sections 1~6**
- `Room.json` SHA-256: `484ac8d7b28d92f9700c9534634bad92c5c7037a2a1d5488f47182d42689e0b2`
- `Chair.usdz` SHA-256: `f86c4d0896646ed971311400d0ca81f5c47acc14bdb6298ea8a6286adc440218`

Package-only overlays: `README.md`, `START_HERE.md`, `BUILD_INFO.md`. All app source and Xcode project files come byte-for-byte from the source tree above.
