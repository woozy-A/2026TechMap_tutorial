# RoomPlan Object Explorer — Final Example v1.4

이 프로젝트는 Tutorial Solution에 확장 기능까지 포함한 Final Example입니다.

- RoomPlan object 목록, identifier 기반 선택, box Highlight
- project-original CC0 Chair 교체와 90° 회전
- Optional Category Correction과 Remove
- Sample `CapturedRoom`과 실제 LiDAR scan이 같은 Explorer pipeline 재사용

Main Tutorial의 필수 범위는 Sections 1~6이며, Category Correction과 Remove는 Optional입니다. 학습 순서는 [공개 DocC Overview](https://woozy-a.github.io/2026TechMap_tutorial/tutorials/roomplanobjectexplorer/)에서 확인할 수 있습니다.
