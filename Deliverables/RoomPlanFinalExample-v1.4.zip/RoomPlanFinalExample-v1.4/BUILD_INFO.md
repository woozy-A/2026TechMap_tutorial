# Build Identity

- Package: `RoomPlanFinalExample-v1.4.zip`
- Source ref: `phase3-final-example-v1.4`
- Annotated tag object: `4fc430f26ca01a3530bf00638b3b5a1313e869ff`
- Peeled source commit: `8fbb51632d6571f58f06ac298771df042a3c9ef6`
- Source tree: `0700b9a91e18ff1508f45b7495e609028ce877fa`
- Main Tutorial: **Sections 1~6 complete**
- Optional Editing: Category Correction + Remove
- `Room.json` SHA-256: `484ac8d7b28d92f9700c9534634bad92c5c7037a2a1d5488f47182d42689e0b2`
- `Chair.usdz` SHA-256: `f86c4d0896646ed971311400d0ca81f5c47acc14bdb6298ea8a6286adc440218`

Package-only overlays: `README.md`, `BUILD_INFO.md`. All app source and Xcode project files come byte-for-byte from the source tree above.
