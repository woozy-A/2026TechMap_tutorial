/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
Final Example-only category correction and removal controls.
*/

import RoomPlan
import UIKit

extension ObjectExplorerViewController {
    private static let editableCategories: [CapturedRoom.Object.Category] = [
        .bed,
        .chair,
        .table,
        .storage
    ]

    func setupOptionalEditing() {
        var categoryConfiguration = UIButton.Configuration.tinted()
        categoryConfiguration.title = "Change Category"
        categoryButton.configuration = categoryConfiguration
        categoryButton.showsMenuAsPrimaryAction = true
        categoryButton.accessibilityIdentifier = "changeCategoryButton"

        var removeConfiguration = UIButton.Configuration.tinted()
        removeConfiguration.title = "Remove"
        removeConfiguration.baseForegroundColor = .systemRed
        removeButton.configuration = removeConfiguration
        removeButton.accessibilityIdentifier = "removeObjectButton"
        removeButton.addAction(
            UIAction { [weak self] _ in
                self?.removeSelectedObject()
            },
            for: .touchUpInside
        )

        actionStackView.insertArrangedSubview(categoryButton, at: 0)
        actionStackView.addArrangedSubview(removeButton)
    }

    func updateOptionalEditingControls() {
        let hasSelection = selectedObjectID != nil
        let hasReplacement = selectedObjectID.map(replacedObjectIDs.contains) ?? false
        let canEdit = hasSelection && !hasReplacement && !isReplacingModel

        categoryButton.isEnabled = canEdit
        categoryButton.menu = canEdit ? makeCategoryMenu() : nil
        removeButton.isEnabled = hasSelection && !isReplacingModel
    }

    func effectiveCategory(
        for object: CapturedRoom.Object
    ) -> CapturedRoom.Object.Category {
        editedCategoryByID[object.identifier] ?? object.category
    }

    private func makeCategoryMenu() -> UIMenu {
        let currentCategory = selectedObject.map(effectiveCategory(for:))
        let actions = Self.editableCategories.map { category in
            UIAction(
                title: category.displayName,
                state: category == currentCategory ? .on : .off
            ) { [weak self] _ in
                self?.changeSelectedCategory(to: category)
            }
        }
        return UIMenu(children: actions)
    }

    private func changeSelectedCategory(
        to category: CapturedRoom.Object.Category
    ) {
        guard let selectedObject,
              effectiveCategory(for: selectedObject) != category else { return }

        if category == selectedObject.category {
            editedCategoryByID.removeValue(forKey: selectedObject.identifier)
        } else {
            editedCategoryByID[selectedObject.identifier] = category
        }

        objectSections = makeEditedObjectSections()
        refreshListSelection()
        updateControls()
        updateOptionalEditingControls()
        updateStatus()
    }

    private func makeEditedObjectSections() -> [ObjectSection] {
        let groupedObjects = Dictionary(grouping: objects) { object in
            effectiveCategory(for: object)
        }
        return groupedObjects
            .map { ObjectSection(category: $0.key, objects: $0.value) }
            .sorted { $0.category.displayName < $1.category.displayName }
    }

    private func removeSelectedObject() {
        guard let selectedObjectID else { return }

        objects.removeAll { $0.identifier == selectedObjectID }
        objectSections = makeEditedObjectSections()
        displayedEntityByID.removeValue(forKey: selectedObjectID)?.removeFromParent()
        boxEntityByID.removeValue(forKey: selectedObjectID)
        replacedObjectIDs.remove(selectedObjectID)
        rotationQuarterTurnsByID.removeValue(forKey: selectedObjectID)
        editedCategoryByID.removeValue(forKey: selectedObjectID)
        self.selectedObjectID = nil

        tableView.reloadData()
        updateHighlight()
        updateControls()
        updateOptionalEditingControls()
        updateStatus()
        frameRoom()
    }
}
