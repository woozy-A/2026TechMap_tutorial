# Build Identity

- Package: `RoomPlanTutorialSolution-v2.4.zip`
- Source ref: `tutorial-solution-v2.4`
- Annotated tag object: `855d2dc15a019c92245b06bfbcc852fe166c3c2d`
- Peeled source commit: `49e1e24c81cefba1c8be392354422e2f7bc3de86`
- Source tree: `6250c257d32c89d0d622e63455a8dc93bf6447b2`
- Starter → Solution learner diff: `+89/-17`
- Main Tutorial: **Sections 1~6 complete**
- `Room.json` SHA-256: `484ac8d7b28d92f9700c9534634bad92c5c7037a2a1d5488f47182d42689e0b2`
- `Chair.usdz` SHA-256: `f86c4d0896646ed971311400d0ca81f5c47acc14bdb6298ea8a6286adc440218`

Package-only overlays: `README.md`, `START_HERE.md`, `BUILD_INFO.md`. All app source and Xcode project files come byte-for-byte from the source tree above.
