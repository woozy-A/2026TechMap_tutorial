# RoomPlan Object Explorer — Tutorial Solution v2.4

이 프로젝트는 Main Tutorial Section 1~6을 모두 완료한 누적 Solution입니다.

완성 흐름은 `Room.json → CapturedRoom → objects → identifier → dimensions / transform → Entity → Highlight → 3D Chair → Rotation`입니다. Category Correction과 Remove는 Main Tutorial 범위가 아니므로 포함하지 않습니다.

`RoomPlanExampleApp.xcodeproj`를 열고 **Explore Sample Room**을 실행한 뒤 Chair를 선택해 Highlight, **Replace with 3D Chair**, **Rotate 90°**를 확인할 수 있습니다. 코드를 단계별로 비교하려면 [공개 DocC Overview](https://woozy-a.github.io/2026TechMap_tutorial/tutorials/roomplanobjectexplorer/)에서 **RoomPlan Object Explorer 만들기**를 선택하세요.
