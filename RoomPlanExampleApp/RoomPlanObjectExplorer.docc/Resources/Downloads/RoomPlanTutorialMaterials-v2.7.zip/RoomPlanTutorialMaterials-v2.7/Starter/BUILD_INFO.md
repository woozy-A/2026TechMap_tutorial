# Build Identity

- Package: `RoomPlanTutorialStarter-v2.6.zip`
- Source ref: `tutorial-starter-v2.6`
- Annotated tag object: `ff0c33b6acf6d105217551397444467a24ea4731`
- Peeled source commit: `3c11f96f56bc8d4ffb2b56ad648061185969ea65`
- Source tree: `c961457cc9f4fb8b1b37d1bf81121690ef0abfe0`
- Expected baseline: **Start Section 1**
- `Room.json` SHA-256: `484ac8d7b28d92f9700c9534634bad92c5c7037a2a1d5488f47182d42689e0b2`
- Bundled furniture assets: **none**

Package-only changes are this file, `START_HERE.md`, the Pages preparation script, removal of the personal Development Team, and a generic sample Bundle ID. The learner adds `Chair.usdz` in Section 5.
