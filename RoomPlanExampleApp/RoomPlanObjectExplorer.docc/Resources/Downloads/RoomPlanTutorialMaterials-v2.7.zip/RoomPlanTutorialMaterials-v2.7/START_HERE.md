# RoomPlan Tutorial Materials v2.7

1. Starter/RoomPlanExampleApp.xcodeproj를 엽니다. 앱 코드는 검증된 Starter v2.6입니다.
2. Main Section 1~4를 진행합니다. Starter에는 의자가 아직 들어 있지 않습니다.
3. Section 5에서 Assets/Chair.usdz를 Xcode Resources에 넣고 앱 target을 체크합니다.
4. 다른 의자는 Assets/README.md의 같은 파일명 교체 방법을 사용하세요.

Assets는 Original Office Chair v2입니다. 기존 v1 ZIP은 변경하지 않았습니다.
실제 방 스캔은 LiDAR 기기에서만 가능하고, Main은 Simulator로 진행합니다.
